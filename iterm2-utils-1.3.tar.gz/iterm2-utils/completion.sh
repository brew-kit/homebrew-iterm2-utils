#!/bin/bash
if ! pgrep -f demo.py >/dev/null; then
  /opt/homebrew/opt/iterm2-utils/libexec/bin/python /opt/homebrew/opt/iterm2-utils/libexec/default_ignorable.py &
fi
