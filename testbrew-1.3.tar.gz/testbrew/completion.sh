#!/bin/bash
if ! pgrep -f demo.py >/dev/null; then
  /opt/homebrew/opt/testbrew/demo.py &
fi
